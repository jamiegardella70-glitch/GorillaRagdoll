# GorillaRagdoll (BepInEx plugin for Gorilla Tag)

Slow motion + ports of **Ultimate Ragdoll 9.0.0** (Int_Void) and **RagdollView 1.2.1** (Lakatrazz) from BONELAB.

## Controls (all rebindable in `BepInEx/config/com.gorillaragdoll.codemod.cfg`)
| Action | Controller | Keyboard |
|---|---|---|
| Toggle ragdoll | Left stick click | R |
| Toggle first / third person (while ragdolled) | Right stick click | T |
| Orbit third-person camera | Right stick left/right | – |
| Toggle slow motion | Left B/Y (secondary) | G |

## Features
- **Slow motion**: eased `Time.timeScale` (+ physics step), configurable scale, optional auto slow-mo while ragdolled.
- **Ragdoll** (from Ultimate Ragdoll): manual toggle, weak-but-controllable arms, floppy left/right arm, torso stiffness, stand-up cooldown, max ragdoll time, max speed to stand, velocity fix, scale by player size, auto-ragdoll on hard fall / impact / launch / wall crash.
- **Ragdoll view** (from RagdollView): camera follows the ragdoll head; `RotationFollow` 0..1 trades full tumbling for a comfortable upright view.
- **Third-person view**: orbit camera behind the ragdoll with collision pull-in and smoothing.
- **Sharing**: state goes out over Photon player properties. Other players running this plugin see a floating RAGDOLL / SLOW-MO label. Your tracked head and hands tumbling is visible to everyone in the room through normal rig networking.

## Where it runs
Offline and in **MODDED** rooms only. It switches itself off in public lobbies on purpose; the game blocks modded movement there, and this plugin does not try to get around that.

## Not ported (no Gorilla Tag equivalent)
Downed state, NPC ragdoll tools, breakable grip, footstep mute, vehicle exit, BoneLib/BoneMenu (use the config file, or GorillaLib's menu).

## Build
Needs the .NET SDK, BepInEx 5 installed in Gorilla Tag, and the game's `Managed` DLLs:
```
dotnet build -c Release -p:GTDir="C:\Path\To\Gorilla Tag"
```
The DLL is copied to `BepInEx/plugins/GorillaRagdoll/` automatically.

## Untested
Written without the game assemblies or a compiler. Game API names (`GTPlayer.turnParent`, `playerRigidBody`, `GorillaTagger.OnPlayerSpawned`, `VRRigCache.TryGetVrrig`, `disableMovement`) vary between versions; if the build errors, those are the lines to adjust (`Util.cs`, `NetSync.cs`, `Plugin.cs`).
