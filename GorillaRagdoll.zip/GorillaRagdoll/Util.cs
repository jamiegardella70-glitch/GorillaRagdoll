using System.Collections.Generic;
using ExitGames.Client.Photon;
using GorillaLocomotion;
using Photon.Pun;
using UnityEngine;
using UnityEngine.XR;

namespace GorillaRagdoll
{
    /// <summary>Only run offline or in MODDED rooms (Gorilla Tag disables mods in public lobbies on purpose).</summary>
    internal static class Gate
    {
        public static bool Allowed
        {
            get
            {
                if (!Cfg.Enabled.Value) return false;
                if (!PhotonNetwork.InRoom) return true;
                var props = PhotonNetwork.CurrentRoom.CustomProperties;
                object gm;
                if (props != null && props.TryGetValue("gameMode", out gm) && gm is string s)
                    return s.Contains("MODDED");
                return false;
            }
        }
    }

    internal static class Rig
    {
        public static GTPlayer P { get { return GTPlayer.Instance; } }
        public static Transform Cam { get { return GorillaTagger.Instance.mainCamera.transform; } }
        public static Transform Root { get { return P.turnParent.transform; } }
        public static Transform LeftHand { get { return P.leftControllerTransform; } }
        public static Transform RightHand { get { return P.rightControllerTransform; } }
        public static Rigidbody Body { get { return P.playerRigidBody; } }
        public static float Scale { get { return Cfg.ScaleByAvatarSize.Value ? Mathf.Max(0.1f, P.scale) : 1f; } }
        public static bool Ready { get { return GTPlayer.Instance != null && GorillaTagger.Instance != null && GorillaTagger.Instance.mainCamera != null; } }

        /// <summary>Move/rotate the XR rig root so the HMD ends up at pos (and the root takes rot).</summary>
        public static void PlaceRig(Vector3 hmdPos, Quaternion rootRot)
        {
            Root.rotation = rootRot;
            Root.position += hmdPos - Cam.position;
        }

        public static void SetMovementDisabled(bool v)
        {
            // Field name differs between game versions; set it if it exists.
            var f = typeof(GTPlayer).GetField("disableMovement");
            if (f != null) f.SetValue(P, v);
        }
    }

    internal static class Pad
    {
        static readonly Dictionary<string, bool> prev = new Dictionary<string, bool>();

        // Call once per frame per binding (edge detection).
        public static bool Pressed(string id, PadButton b, KeyCode key)
        {
            bool now = false;
            if (key != KeyCode.None && Input.GetKey(key)) now = true;
            if (!now && b != PadButton.None)
            {
                XRNode node = (b == PadButton.LeftStickClick || b == PadButton.LeftPrimary || b == PadButton.LeftSecondary) ? XRNode.LeftHand : XRNode.RightHand;
                InputFeatureUsage<bool> u;
                switch (b)
                {
                    case PadButton.LeftStickClick:
                    case PadButton.RightStickClick: u = CommonUsages.primary2DAxisClick; break;
                    case PadButton.LeftPrimary:
                    case PadButton.RightPrimary: u = CommonUsages.primaryButton; break;
                    default: u = CommonUsages.secondaryButton; break;
                }
                bool v;
                if (InputDevices.GetDeviceAtXRNode(node).TryGetFeatureValue(u, out v)) now = v;
            }
            bool was; prev.TryGetValue(id, out was); prev[id] = now;
            return now && !was;
        }

        public static float RightStickX()
        {
            Vector2 v;
            return InputDevices.GetDeviceAtXRNode(XRNode.RightHand).TryGetFeatureValue(CommonUsages.primary2DAxis, out v) ? v.x : 0f;
        }
    }
}
