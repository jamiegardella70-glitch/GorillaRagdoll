using System.Collections.Generic;
using UnityEngine;

namespace GorillaRagdoll
{
    /// <summary>
    /// Physical ragdoll proxy for the player (head, chest, pelvis, two arms). While active, the XR rig is
    /// moved by RagdollView to follow the ragdoll, so everyone sees your tracked head/hands tumble.
    /// Port/adaptation of Ultimate Ragdoll's manual + auto ragdoll, weak arms, floppy limbs, cooldowns,
    /// stand-up limits, auto triggers (fall/impact/launch/wall) and velocity fix.
    /// </summary>
    internal class RagdollController : MonoBehaviour
    {
        public static RagdollController I;
        public bool Active;
        public Rigidbody Head, Chest, Pelvis, HandL, HandR;
        Rigidbody elbowL, elbowR;
        readonly List<GameObject> parts = new List<GameObject>();
        float startTime, nextAllowed;
        Vector3 prevVel;
        PhysicMaterial mat;

        void Awake() { I = this; }

        void Update()
        {
            if (!Rig.Ready) return;
            if (!Gate.Allowed) { if (Active) Stop(true); return; }

            if (Pad.Pressed("ragdoll", Cfg.RagdollButton.Value, Cfg.RagdollKey.Value))
            {
                if (Active) Stop(false); else Begin();
            }

            if (Active && Cfg.MaxRagdollTime.Value > 0f && Time.time - startTime > Cfg.MaxRagdollTime.Value)
                Stop(true);
        }

        void FixedUpdate()
        {
            if (!Rig.Ready || !Gate.Allowed) return;
            var body = Rig.Body;

            if (Active)
            {
                // Keep the real player body parked so it doesn't fight the ragdoll.
                if (body != null) { body.velocity = Vector3.zero; }
                DriveArms();
                return;
            }

            if (body == null) return;
            Vector3 v = body.velocity;
            Vector3 dv = v - prevVel;
            float s = Rig.Scale;

            bool trigger = false;
            if (Time.time >= nextAllowed)
            {
                if (Cfg.AutoFall.Value && prevVel.y < -Cfg.FallSpeed.Value * s && v.y > prevVel.y * 0.3f) trigger = true;
                if (Cfg.AutoImpact.Value && dv.magnitude > Cfg.ImpactDelta.Value * s) trigger = true;
                if (Cfg.AutoWall.Value && new Vector3(dv.x, 0, dv.z).magnitude > Cfg.WallDelta.Value * s) trigger = true;
                if (Cfg.AutoLaunch.Value && v.magnitude > Cfg.LaunchSpeed.Value * s) trigger = true;
            }
            prevVel = v;
            if (trigger) Begin();
        }

        public void Begin()
        {
            if (Active || Time.time < nextAllowed || !Rig.Ready) return;
            Build();
            Active = true;
            startTime = Time.time;
            Rig.SetMovementDisabled(true);
            Plugin.Log.LogInfo("Ragdoll ON");
        }

        public void Stop(bool force)
        {
            if (!Active) return;
            if (!force && Cfg.MaxStandSpeed.Value > 0f && Head.velocity.magnitude > Cfg.MaxStandSpeed.Value * Rig.Scale) return;

            Vector3 headPos = Head.position;
            Vector3 vel = Head.velocity;
            float yaw = RagdollView.CurrentYaw();
            Teardown();
            Active = false;

            // Stand upright where the head ended up.
            Rig.PlaceRig(headPos, Quaternion.Euler(0f, yaw, 0f));
            Rig.SetMovementDisabled(false);
            var body = Rig.Body;
            if (body != null)
            {
                if (Cfg.VelocityFix.Value) vel = Vector3.ClampMagnitude(vel, Cfg.VelocityFixLimit.Value);
                body.velocity = vel;
            }
            prevVel = Vector3.zero;
            nextAllowed = Time.time + Cfg.Cooldown.Value;
            Plugin.Log.LogInfo("Ragdoll OFF");
        }

        // ---------- build ----------
        void Build()
        {
            float s = Rig.Scale;
            Transform cam = Rig.Cam;
            Vector3 up = Vector3.up;
            Quaternion yawRot = Quaternion.Euler(0f, cam.eulerAngles.y, 0f);
            Vector3 right = yawRot * Vector3.right;
            Vector3 headPos = cam.position;
            Vector3 initVel = Rig.Body != null ? Rig.Body.velocity : Vector3.zero;

            mat = new PhysicMaterial("GRMat") { dynamicFriction = 0.6f, staticFriction = 0.6f, bounciness = Cfg.Bounciness.Value };
            float m = Cfg.BodyMass.Value;

            Head = Sphere("GR_Head", headPos, 0.13f * s, m * 0.12f, yawRot);
            Chest = Capsule("GR_Chest", headPos - up * 0.30f * s, 0.14f * s, 0.34f * s, m * 0.35f, yawRot);
            Pelvis = Capsule("GR_Pelvis", headPos - up * 0.62f * s, 0.13f * s, 0.26f * s, m * 0.30f, yawRot);

            Joint(Head, Chest, headPos - up * 0.15f * s, 50f, 40f, 40f);
            Joint(Chest, Pelvis, headPos - up * 0.47f * s, 30f, 25f, 25f);

            Vector3 shL = Chest.position - right * 0.20f * s + up * 0.10f * s;
            Vector3 shR = Chest.position + right * 0.20f * s + up * 0.10f * s;
            Vector3 hL = Rig.LeftHand.position, hR = Rig.RightHand.position;
            elbowL = Sphere("GR_ElbowL", Vector3.Lerp(shL, hL, 0.5f), 0.06f * s, m * 0.04f, yawRot);
            elbowR = Sphere("GR_ElbowR", Vector3.Lerp(shR, hR, 0.5f), 0.06f * s, m * 0.04f, yawRot);
            HandL = Sphere("GR_HandL", hL, 0.07f * s, m * 0.04f, yawRot);
            HandR = Sphere("GR_HandR", hR, 0.07f * s, m * 0.04f, yawRot);
            Joint(elbowL, Chest, shL, 60f, 70f, 70f);
            Joint(elbowR, Chest, shR, 60f, 70f, 70f);
            Joint(HandL, elbowL, elbowL.position, 40f, 50f, 50f);
            Joint(HandR, elbowR, elbowR.position, 40f, 50f, 50f);

            // Don't collide with the real player colliders.
            var p = Rig.P;
            foreach (var part in parts)
            {
                var c = part.GetComponent<Collider>();
                if (p.headCollider != null) Physics.IgnoreCollision(c, p.headCollider);
                if (p.bodyCollider != null) Physics.IgnoreCollision(c, p.bodyCollider);
            }

            foreach (var part in parts) part.GetComponent<Rigidbody>().velocity = initVel;
        }

        Rigidbody Sphere(string n, Vector3 pos, float r, float mass, Quaternion rot)
        {
            var go = new GameObject(n); go.transform.SetPositionAndRotation(pos, rot);
            var c = go.AddComponent<SphereCollider>(); c.radius = r; c.sharedMaterial = mat;
            return Finish(go, mass);
        }

        Rigidbody Capsule(string n, Vector3 pos, float r, float h, float mass, Quaternion rot)
        {
            var go = new GameObject(n); go.transform.SetPositionAndRotation(pos, rot);
            var c = go.AddComponent<CapsuleCollider>(); c.radius = r; c.height = h; c.direction = 1; c.sharedMaterial = mat;
            return Finish(go, mass);
        }

        Rigidbody Finish(GameObject go, float mass)
        {
            var rb = go.AddComponent<Rigidbody>();
            rb.mass = Mathf.Max(0.05f, mass);
            rb.drag = 0.1f; rb.angularDrag = 0.8f;
            rb.interpolation = RigidbodyInterpolation.Interpolate;
            rb.collisionDetectionMode = CollisionDetectionMode.ContinuousDynamic;
            parts.Add(go);
            return rb;
        }

        void Joint(Rigidbody body, Rigidbody parent, Vector3 worldAnchor, float twist, float swing1, float swing2)
        {
            // Torso stiffness narrows the limits.
            float k = Mathf.Lerp(1f, 0.1f, Cfg.TorsoStiffness.Value);
            var j = body.gameObject.AddComponent<CharacterJoint>();
            j.connectedBody = parent;
            j.autoConfigureConnectedAnchor = true;
            j.anchor = body.transform.InverseTransformPoint(worldAnchor);
            j.enablePreprocessing = false;
            var lo = j.lowTwistLimit; lo.limit = -twist * k; j.lowTwistLimit = lo;
            var hi = j.highTwistLimit; hi.limit = twist * k; j.highTwistLimit = hi;
            var s1 = j.swing1Limit; s1.limit = swing1 * k; j.swing1Limit = s1;
            var s2 = j.swing2Limit; s2.limit = swing2 * k; j.swing2Limit = s2;
        }

        void Teardown()
        {
            foreach (var p in parts) if (p != null) Object.Destroy(p);
            parts.Clear();
            Head = Chest = Pelvis = HandL = HandR = elbowL = elbowR = null;
        }

        // ---------- weak arms ----------
        void DriveArms()
        {
            if (!Cfg.WeakArms.Value) return;
            float str = Cfg.ArmStrength.Value;
            if (str <= 0f) return;
            if (!Cfg.FloppyLeft.Value) Pull(HandL, Rig.LeftHand.position, str);
            if (!Cfg.FloppyRight.Value) Pull(HandR, Rig.RightHand.position, str);
        }

        static void Pull(Rigidbody hand, Vector3 target, float str)
        {
            if (hand == null) return;
            Vector3 err = target - hand.position;
            Vector3 acc = (err * 120f - hand.velocity * 12f) * str;
            hand.AddForce(Vector3.ClampMagnitude(acc, 200f), ForceMode.Acceleration);
        }

        void OnDestroy() { Teardown(); Rig.SetMovementDisabled(false); }
    }
}
