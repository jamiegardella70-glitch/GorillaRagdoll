using BepInEx.Configuration;
using UnityEngine;

namespace GorillaRagdoll
{
    public enum PadButton { None, LeftStickClick, RightStickClick, LeftPrimary, LeftSecondary, RightPrimary, RightSecondary }

    internal static class Cfg
    {
        // General
        public static ConfigEntry<bool> Enabled;
        public static ConfigEntry<PadButton> RagdollButton; public static ConfigEntry<KeyCode> RagdollKey;
        public static ConfigEntry<PadButton> ViewButton;    public static ConfigEntry<KeyCode> ViewKey;
        public static ConfigEntry<PadButton> SlowMoButton;  public static ConfigEntry<KeyCode> SlowMoKey;

        // Slow motion
        public static ConfigEntry<float> SlowScale, SlowEase;
        public static ConfigEntry<bool> SlowOnRagdoll;

        // Ragdoll
        public static ConfigEntry<float> Cooldown, MaxRagdollTime, MaxStandSpeed, ArmStrength, TorsoStiffness, BodyMass, Bounciness;
        public static ConfigEntry<bool> WeakArms, FloppyLeft, FloppyRight, VelocityFix;
        public static ConfigEntry<float> VelocityFixLimit;
        public static ConfigEntry<bool> ScaleByAvatarSize;

        // Auto triggers
        public static ConfigEntry<bool> AutoFall, AutoImpact, AutoLaunch, AutoWall;
        public static ConfigEntry<float> FallSpeed, ImpactDelta, LaunchSpeed, WallDelta;

        // View
        public static ConfigEntry<bool> RagdollView;
        public static ConfigEntry<float> ViewRotationFollow;
        public static ConfigEntry<float> TPDistance, TPHeight, TPTurnSpeed, TPSmoothing;
        public static ConfigEntry<bool> ThirdPersonDefault;

        // Network
        public static ConfigEntry<bool> ShareState, ShowLabels;

        public static void Bind(ConfigFile c)
        {
            Enabled = c.Bind("General", "Enabled", true, "Master switch. The mod also only runs offline or in MODDED rooms.");
            RagdollButton = c.Bind("Controls", "RagdollButton", PadButton.LeftStickClick, "Controller button to toggle ragdoll.");
            RagdollKey = c.Bind("Controls", "RagdollKey", KeyCode.R, "Keyboard key to toggle ragdoll.");
            ViewButton = c.Bind("Controls", "ThirdPersonButton", PadButton.RightStickClick, "Controller button to switch first/third person while ragdolled.");
            ViewKey = c.Bind("Controls", "ThirdPersonKey", KeyCode.T, "Keyboard key to switch first/third person while ragdolled.");
            SlowMoButton = c.Bind("Controls", "SlowMoButton", PadButton.LeftSecondary, "Controller button to toggle slow motion.");
            SlowMoKey = c.Bind("Controls", "SlowMoKey", KeyCode.G, "Keyboard key to toggle slow motion.");

            SlowScale = c.Bind("SlowMotion", "TimeScale", 0.3f, new ConfigDescription("Game speed while slow motion is on.", new AcceptableValueRange<float>(0.05f, 0.95f)));
            SlowEase = c.Bind("SlowMotion", "EaseSpeed", 2.5f, "How fast the time scale blends in/out (per real second).");
            SlowOnRagdoll = c.Bind("SlowMotion", "SlowWhileRagdolled", false, "Automatically slow time while ragdolled.");

            Cooldown = c.Bind("Ragdoll", "StandUpCooldown", 1.0f, "Seconds before you can ragdoll again after standing.");
            MaxRagdollTime = c.Bind("Ragdoll", "MaxRagdollTime", 0f, "Force stand-up after this many seconds (0 = never).");
            MaxStandSpeed = c.Bind("Ragdoll", "MaxSpeedToStand", 6f, "You can only stand while the ragdoll is slower than this (m/s). 0 = no limit.");
            WeakArms = c.Bind("Ragdoll", "WeakArms", true, "Arms follow your controllers while ragdolled, but weakly. Off = fully limp.");
            ArmStrength = c.Bind("Ragdoll", "ArmStrength", 0.35f, new ConfigDescription("0 = limp, 1 = strong.", new AcceptableValueRange<float>(0f, 1f)));
            FloppyLeft = c.Bind("Ragdoll", "FloppyLeftArm", false, "Left arm always limp.");
            FloppyRight = c.Bind("Ragdoll", "FloppyRightArm", false, "Right arm always limp.");
            TorsoStiffness = c.Bind("Ragdoll", "TorsoStiffness", 0.15f, new ConfigDescription("0 = full ragdoll, 1 = rigid.", new AcceptableValueRange<float>(0f, 1f)));
            BodyMass = c.Bind("Ragdoll", "BodyMass", 8f, "Total ragdoll mass (kg).");
            Bounciness = c.Bind("Ragdoll", "Bounciness", 0.05f, "Physic material bounciness.");
            ScaleByAvatarSize = c.Bind("Ragdoll", "ScaleByPlayerSize", true, "Scale the ragdoll and trigger thresholds with the player's scale.");
            VelocityFix = c.Bind("Fixes", "VelocityFix", true, "Clamp velocity when standing so you don't launch away.");
            VelocityFixLimit = c.Bind("Fixes", "VelocityLimit", 6f, "Max speed (m/s) kept when standing up.");

            AutoFall = c.Bind("AutoRagdoll", "Fall", true, "Ragdoll after landing from a hard fall.");
            FallSpeed = c.Bind("AutoRagdoll", "FallSpeed", 12f, "Downward speed (m/s) that counts as a hard fall.");
            AutoImpact = c.Bind("AutoRagdoll", "Impact", true, "Ragdoll on a sudden velocity change.");
            ImpactDelta = c.Bind("AutoRagdoll", "ImpactDelta", 14f, "Velocity change in one physics step (m/s) that counts as an impact.");
            AutoLaunch = c.Bind("AutoRagdoll", "Launch", true, "Ragdoll when moving very fast.");
            LaunchSpeed = c.Bind("AutoRagdoll", "LaunchSpeed", 18f, "Speed (m/s) that counts as being launched.");
            AutoWall = c.Bind("AutoRagdoll", "WallCrash", true, "Ragdoll when hitting a wall at speed.");
            WallDelta = c.Bind("AutoRagdoll", "WallCrashDelta", 12f, "Horizontal velocity change (m/s) that counts as a wall crash.");

            RagdollView = c.Bind("View", "RagdollView", true, "Camera follows the ragdoll's head while ragdolled.");
            ViewRotationFollow = c.Bind("View", "RotationFollow", 1f, new ConfigDescription("0 = camera keeps upright yaw only (comfortable), 1 = fully follows head tumbling.", new AcceptableValueRange<float>(0f, 1f)));
            ThirdPersonDefault = c.Bind("View", "StartInThirdPerson", false, "Start each ragdoll in third person.");
            TPDistance = c.Bind("View", "ThirdPersonDistance", 2.2f, "Camera distance behind the ragdoll (m).");
            TPHeight = c.Bind("View", "ThirdPersonHeight", 0.7f, "Camera height above the ragdoll (m).");
            TPTurnSpeed = c.Bind("View", "ThirdPersonOrbitSpeed", 120f, "Degrees/sec the right thumbstick orbits the third-person camera.");
            TPSmoothing = c.Bind("View", "ThirdPersonSmoothing", 0.12f, "Camera follow smoothing time (s).");

            ShareState = c.Bind("Network", "ShareState", true, "Share ragdoll/slow-mo state with other players running this mod.");
            ShowLabels = c.Bind("Network", "ShowLabels", true, "Show a floating label over other mod users who are ragdolled / in slow motion.");
        }
    }
}
