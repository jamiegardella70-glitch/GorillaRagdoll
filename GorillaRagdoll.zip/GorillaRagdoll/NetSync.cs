using System.Collections.Generic;
using ExitGames.Client.Photon;
using Photon.Pun;
using Photon.Realtime;
using UnityEngine;

namespace GorillaRagdoll
{
    /// <summary>
    /// Shares state over Photon player custom properties so other players running this mod can see
    /// a floating "RAGDOLL / SLOW-MO" label over you. (Your tracked head/hands tumbling is already
    /// visible to everyone in the room through normal rig networking.)
    /// </summary>
    internal class NetSync : MonoBehaviour
    {
        const string KRag = "GR_rag", KSlow = "GR_slow", KView = "GR_tp";
        bool lastRag, lastTp; float lastSlow = 1f;
        float nextPush, nextScan;
        readonly Dictionary<int, TextMesh> labels = new Dictionary<int, TextMesh>();

        void Update()
        {
            if (!PhotonNetwork.InRoom) { ClearLabels(); return; }
            if (Cfg.ShareState.Value && Time.unscaledTime >= nextPush) { nextPush = Time.unscaledTime + 0.25f; Push(); }
            if (Time.unscaledTime >= nextScan) { nextScan = Time.unscaledTime + 0.5f; Scan(); }
        }

        void Push()
        {
            bool rag = RagdollController.I != null && RagdollController.I.Active;
            float slow = SlowMo.I != null ? Mathf.Round(SlowMo.I.Current * 100f) / 100f : 1f;
            bool tp = rag && RagdollView.I != null && RagdollView.I.ThirdPerson;
            if (rag == lastRag && Mathf.Approximately(slow, lastSlow) && tp == lastTp) return;
            lastRag = rag; lastSlow = slow; lastTp = tp;
            var h = new Hashtable { { KRag, rag }, { KSlow, slow }, { KView, tp } };
            PhotonNetwork.LocalPlayer.SetCustomProperties(h);
        }

        void Scan()
        {
            if (!Cfg.ShowLabels.Value) { ClearLabels(); return; }
            var seen = new HashSet<int>();
            foreach (Player p in PhotonNetwork.PlayerListOthers)
            {
                object r, s;
                bool hasR = p.CustomProperties.TryGetValue(KRag, out r);
                bool hasS = p.CustomProperties.TryGetValue(KSlow, out s);
                if (!hasR && !hasS) continue;
                bool rag = hasR && r is bool && (bool)r;
                float slow = hasS && s is float ? (float)s : 1f;
                string text = "";
                if (rag) text += "RAGDOLL";
                if (slow < 0.99f) text += (text.Length > 0 ? "\n" : "") + "SLOW-MO " + slow.ToString("0.0#") + "x";
                if (text.Length == 0) { Remove(p.ActorNumber); continue; }

                VRRig rig = FindRig(p);
                if (rig == null) continue;
                seen.Add(p.ActorNumber);
                TextMesh tm;
                if (!labels.TryGetValue(p.ActorNumber, out tm) || tm == null)
                {
                    tm = MakeLabel(rig.transform);
                    labels[p.ActorNumber] = tm;
                }
                tm.text = text;
            }
            var stale = new List<int>();
            foreach (var kv in labels) if (!seen.Contains(kv.Key)) stale.Add(kv.Key);
            foreach (int id in stale) Remove(id);
        }

        static VRRig FindRig(Player p)
        {
            // API differs a little between game versions; adjust here if it fails to compile.
            var np = NetworkSystem.Instance.GetPlayer(p.ActorNumber);
            RigContainer rc;
            if (np != null && VRRigCache.Instance.TryGetVrrig(np, out rc)) return rc.Rig;
            return null;
        }

        static TextMesh MakeLabel(Transform rigT)
        {
            var go = new GameObject("GR_Label");
            go.transform.SetParent(rigT, false);
            go.transform.localPosition = new Vector3(0f, 0.75f, 0f);
            var tm = go.AddComponent<TextMesh>();
            tm.anchor = TextAnchor.MiddleCenter; tm.alignment = TextAlignment.Center;
            tm.fontSize = 64; tm.characterSize = 0.02f; tm.color = new Color(1f, 0.75f, 0.2f);
            Font f = null;
            try { f = Resources.GetBuiltinResource<Font>("LegacyRuntime.ttf"); } catch { }
            if (f == null) { try { f = Resources.GetBuiltinResource<Font>("Arial.ttf"); } catch { } }
            if (f != null) { tm.font = f; go.GetComponent<MeshRenderer>().sharedMaterial = f.material; }
            go.AddComponent<Billboard>();
            return tm;
        }

        void Remove(int id)
        {
            TextMesh tm;
            if (labels.TryGetValue(id, out tm)) { if (tm != null) Destroy(tm.gameObject); labels.Remove(id); }
        }

        void ClearLabels()
        {
            foreach (var kv in labels) if (kv.Value != null) Destroy(kv.Value.gameObject);
            labels.Clear();
        }

        void OnDestroy() { ClearLabels(); }
    }

    internal class Billboard : MonoBehaviour
    {
        void LateUpdate()
        {
            if (!Rig.Ready) return;
            transform.rotation = Quaternion.LookRotation(transform.position - Rig.Cam.position, Vector3.up);
        }
    }
}
