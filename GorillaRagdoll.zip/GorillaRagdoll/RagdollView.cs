using UnityEngine;

namespace GorillaRagdoll
{
    /// <summary>
    /// Port of Lakatrazz's RagdollView + Ultimate Ragdoll's built-in view, plus a third-person camera.
    /// Works by moving/rotating the XR rig root so the HMD sits at the chosen camera pose.
    /// </summary>
    internal class RagdollView : MonoBehaviour
    {
        public static RagdollView I;
        public bool ThirdPerson;
        float tpYaw;
        Vector3 tpPos, tpVel;
        bool wasActive;
        float lastYaw;

        void Awake() { I = this; }
        void OnEnable() { Application.onBeforeRender += Apply; }
        void OnDisable() { Application.onBeforeRender -= Apply; }

        public static float CurrentYaw() { return I != null ? I.lastYaw : 0f; }

        void Update()
        {
            var rc = RagdollController.I;
            bool active = rc != null && rc.Active && Rig.Ready;

            if (active && !wasActive)
            {
                ThirdPerson = Cfg.ThirdPersonDefault.Value;
                tpYaw = Rig.Cam.eulerAngles.y;
                lastYaw = tpYaw;
                tpPos = Rig.Cam.position;
            }
            wasActive = active;
            if (!active) return;

            if (Pad.Pressed("view", Cfg.ViewButton.Value, Cfg.ViewKey.Value))
            {
                ThirdPerson = !ThirdPerson;
                tpPos = Rig.Cam.position; tpVel = Vector3.zero;
            }

            if (ThirdPerson)
                tpYaw += Pad.RightStickX() * Cfg.TPTurnSpeed.Value * Time.unscaledDeltaTime;
        }

        void LateUpdate() { Apply(); }

        void Apply()
        {
            var rc = RagdollController.I;
            if (rc == null || !rc.Active || rc.Head == null || !Rig.Ready) return;
            if (!Cfg.RagdollView.Value && !ThirdPerson) return;

            Transform head = rc.Head.transform;
            Vector3 headFwd = head.forward; headFwd.y = 0f;
            float headYaw = headFwd.sqrMagnitude > 1e-4f ? Quaternion.LookRotation(headFwd).eulerAngles.y : lastYaw;
            lastYaw = headYaw;

            if (!ThirdPerson)
            {
                // First-person: root follows ragdoll head orientation, HMD tracking is applied on top.
                Quaternion upright = Quaternion.Euler(0f, headYaw, 0f);
                Quaternion rot = Quaternion.Slerp(upright, head.rotation, Cfg.ViewRotationFollow.Value);
                Rig.PlaceRig(head.position, rot);
            }
            else
            {
                Vector3 focus = rc.Chest != null ? rc.Chest.position : head.position;
                Quaternion orbit = Quaternion.Euler(0f, tpYaw, 0f);
                Vector3 desired = focus - orbit * Vector3.forward * Cfg.TPDistance.Value * Rig.Scale
                                  + Vector3.up * Cfg.TPHeight.Value * Rig.Scale;

                // Pull the camera in if something is in the way.
                Vector3 dir = desired - focus;
                RaycastHit hit;
                if (Physics.SphereCast(focus, 0.15f, dir.normalized, out hit, dir.magnitude, ~0, QueryTriggerInteraction.Ignore)
                    && hit.collider.attachedRigidbody == null)
                    desired = focus + dir.normalized * Mathf.Max(0.3f, hit.distance - 0.1f);

                tpPos = Vector3.SmoothDamp(tpPos, desired, ref tpVel, Cfg.TPSmoothing.Value, Mathf.Infinity, Time.unscaledDeltaTime);

                Quaternion look = Quaternion.LookRotation((focus - tpPos).normalized, Vector3.up);
                Quaternion rootRot = Quaternion.Euler(0f, look.eulerAngles.y, 0f); // HMD can still look around
                Rig.PlaceRig(tpPos, rootRot);
            }
        }
    }
}
