using UnityEngine;

namespace GorillaRagdoll
{
    /// <summary>Slow motion by scaling Time.timeScale (and fixedDeltaTime so physics stays smooth).</summary>
    internal class SlowMo : MonoBehaviour
    {
        public static SlowMo I;
        public bool On;
        public float Current = 1f;
        float baseFixed;

        void Awake() { I = this; baseFixed = Time.fixedDeltaTime; }

        void Update()
        {
            if (!Rig.Ready) return;
            if (!Gate.Allowed) { On = false; }
            else if (Pad.Pressed("slowmo", Cfg.SlowMoButton.Value, Cfg.SlowMoKey.Value)) On = !On;

            bool want = On || (Cfg.SlowOnRagdoll.Value && RagdollController.I != null && RagdollController.I.Active);
            float target = want ? Cfg.SlowScale.Value : 1f;
            Current = Mathf.MoveTowards(Current, target, Cfg.SlowEase.Value * Time.unscaledDeltaTime);
            Apply(Current);
        }

        void Apply(float s)
        {
            Time.timeScale = s;
            Time.fixedDeltaTime = baseFixed * s;
        }

        void OnDisable() { Apply(1f); }
        void OnDestroy() { Apply(1f); }
    }
}
