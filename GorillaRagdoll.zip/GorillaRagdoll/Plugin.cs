using BepInEx;
using UnityEngine;

namespace GorillaRagdoll
{
    [BepInPlugin(Guid, "GorillaRagdoll", "1.0.0")]
    public class Plugin : BaseUnityPlugin
    {
        public const string Guid = "com.gorillaragdoll.codemod";
        internal static BepInEx.Logging.ManualLogSource Log;

        void Awake()
        {
            Log = Logger;
            Cfg.Bind(Config);
            GorillaTagger.OnPlayerSpawned(Init);
        }

        void Init()
        {
            var go = new GameObject("GorillaRagdollRoot");
            DontDestroyOnLoad(go);
            go.AddComponent<SlowMo>();
            go.AddComponent<RagdollController>();
            go.AddComponent<RagdollView>();
            go.AddComponent<NetSync>();
            Log.LogInfo("GorillaRagdoll ready.");
        }
    }
}
